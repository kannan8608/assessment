from django.db import models

# Create your models here.
class CustomUser():
    username=models.CharField(null=True,blank=True)