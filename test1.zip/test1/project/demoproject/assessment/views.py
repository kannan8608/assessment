from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.views import APIView





class MemberCRUD(APIView):
    def get(request):
        return HttpResponse("Hello world!")